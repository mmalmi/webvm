import {
  fromHex,
  deriveNodeAddr,
  nodeAddrToHex,
  toHex,
  type DiscoveredPeer,
  type Logger,
  type LinkNegotiationMessage,
  type NodeAddr,
  type Transport,
  type TransportAddress,
  type TransportContext,
  noopLogger,
} from "@fips/core";

import { NostrRelayClient } from "./NostrRelayClient.js";
import { WebRtcAutoConnectPolicy } from "./WebRtcAutoConnectPolicy.js";
import {
  DEFAULT_FIPS_ADVERT_TTL_MS,
  FIPS_ADVERT_D_TAG,
  NostrPeerDiscovery,
  type FipsAdvertContent,
} from "./NostrPeerDiscovery.js";
import type { NostrEvent } from "./NostrRelayClient.js";
import { WebRtcConnection } from "./WebRtcConnection.js";
import { WebRtcAdvertCache } from "./WebRtcAdvertCache.js";
import {
  AsyncEventStream,
  cloneDiscoveredPeer,
  emptyAsyncIterable,
  hasPendingInboundForPeer,
  incomingOfferReplacesPendingDial,
  randomId,
  resolveWebRtcTransportConfig,
  waitForIceGatheringComplete,
  type PendingInboundConnection,
  type AdvertWaiter,
  type ResolvedWebRtcTransportConfig,
} from "./WebRtcTransportSupport.js";
import {
  createWebRtcSignal,
  sendAnswerWithRouteRetry,
  validateWebRtcSignal,
  WebRtcSignalCache,
  type CachedSignal,
  type WebRtcSignal,
} from "./WebRtcSignal.js";
import type { WebRtcTransportConfig } from "./WebRtcTransportConfig.js";
import { cancelOfferRetry, isRetryOfRejectedOffer, retryOffersAfterRestart, sendPendingOffer,
  type PendingDial } from "./WebRtcDial.js";

class IncomingOfferHandoff extends Error {
  constructor() {
    super("incoming WebRTC offer won simultaneous dial");
  }
}

const ADVERT_RESOLUTION_TIMEOUT_MS = 5_000;
const AUTO_RECONNECT_DELAY_MS = 500;
const AUTO_CONNECT_SETTLE_MS = 750;

export class WebRtcTransport implements Transport {
  readonly type = "webrtc";
  readonly mtu: number;
  private ctx?: TransportContext;
  private readonly cfg: ResolvedWebRtcTransportConfig;
  private readonly logger: Logger;
  private readonly RTCPC: typeof RTCPeerConnection;
  private peerDiscovery?: NostrPeerDiscovery;
  private relayClients: NostrRelayClient[] = [];
  private ownsRelayClients = false;
  private readonly conns = new Map<string, WebRtcConnection>(); // by pubkeyHex
  private readonly supersededConnections = new WeakSet<WebRtcConnection>();
  private readonly pendingDials = new Map<string, PendingDial>(); // by sessionId
  private readonly pendingInbound = new Map<string, PendingInboundConnection>(); // by negotiation id
  private readonly pendingConnects = new Map<string, Promise<void>>(); // by pubkeyHex
  private readonly autoConnectPeers = new Set<string>(); // by pubkeyHex
  private readonly pendingAutoConnects = new Set<string>(); // by pubkeyHex
  private readonly knownSessionIds = new Set<string>();
  private readonly seenSessionIds = new Set<string>();
  private readonly signalCache = new WebRtcSignalCache();
  private readonly advertCache: WebRtcAdvertCache;
  private readonly peersWithTraffic = new Set<string>();
  private readonly advertWaiters = new Map<string, Set<AdvertWaiter>>(); // by NodeAddr hex
  private readonly autoReconnectTimers = new Map<string, ReturnType<typeof setTimeout>>();
  private readonly autoConnectAttempts = new Map<string, number>();
  private readonly autoConnectPolicy: WebRtcAutoConnectPolicy;
  private autoConnectAttemptSequence = 0;
  private autoConnectFillTimer?: ReturnType<typeof setTimeout>;
  private discoveryStream?: AsyncEventStream<DiscoveredPeer>;
  private advertCleanup?: () => void;
  private advertRefreshTimer?: ReturnType<typeof setInterval>;
  private stopping = true;

  constructor(config: WebRtcTransportConfig) {
    this.cfg = resolveWebRtcTransportConfig(config);
    this.autoConnectPolicy = new WebRtcAutoConnectPolicy(
      config.preferredAutoConnectPeers ?? [],
    );
    this.advertCache = new WebRtcAdvertCache(
      this.cfg.advertTtlMs ?? DEFAULT_FIPS_ADVERT_TTL_MS,
      (remoteAddr) => this.autoConnectAttempts.delete(remoteAddr),
    );
    this.mtu = this.cfg.mtu;
    this.logger = config.logger ?? noopLogger;
    this.RTCPC =
      config.rtcPeerConnection ??
      ((globalThis as { RTCPeerConnection?: typeof RTCPeerConnection })
        .RTCPeerConnection as typeof RTCPeerConnection);
    if (!this.RTCPC) {
      throw new Error("RTCPeerConnection not available in this environment");
    }
    if (this.cfg.advertiseOnNostr && this.cfg.relays.length === 0 && !this.cfg.discoveryProvider) {
      throw new Error("advertiseOnNostr requires at least one Nostr relay");
    }
  }

  async start(ctx: TransportContext): Promise<void> {
    this.stopping = false;
    this.ctx = ctx;
    this.discoveryStream = new AsyncEventStream<DiscoveredPeer>();
    const sharedRelayClients = this.cfg.relayClients;
    if (this.cfg.discoveryProvider) {
      this.relayClients = [];
      this.ownsRelayClients = false;
    } else if (this.cfg.relays.length === 0) {
      if (sharedRelayClients && sharedRelayClients.length > 0) {
        throw new Error("shared relay clients require matching configured relays");
      }
      this.relayClients = [];
      this.ownsRelayClients = false;
    } else if (sharedRelayClients !== undefined) {
      const configuredUrls = this.cfg.relays.map((url) => new URL(url).toString());
      const sharedUrls = sharedRelayClients.map((client) => new URL(client.url).toString());
      if (
        sharedUrls.length === 0
        || sharedUrls.length !== configuredUrls.length
        || sharedUrls.some((url, index) => url !== configuredUrls[index])
      ) {
        throw new Error("shared relay clients must match configured relays in order");
      }
      this.relayClients = sharedRelayClients;
      this.ownsRelayClients = false;
    } else {
      this.relayClients = this.cfg.relays.map(
        (u) => new NostrRelayClient({
          url: u,
          webSocket: this.cfg.webSocket,
          connectTimeoutMs: this.cfg.relayConnectTimeoutMs,
          logger: this.logger,
        }),
      );
      this.ownsRelayClients = true;
    }
    if (this.relayClients.length > 0 || this.cfg.discoveryProvider) {
      this.peerDiscovery = new NostrPeerDiscovery({
        identity: ctx.localIdentity,
        provider: this.cfg.discoveryProvider,
        relays: this.relayClients,
        discoveryApp: this.cfg.discoveryApp,
        advertTtlMs: this.cfg.advertTtlMs,
        logger: this.logger,
      });
      this.advertCleanup = await this.peerDiscovery.subscribeAdverts(
        (event, advert, sourceRelayUrl) => {
          this.handleAdvert(event, advert, sourceRelayUrl).catch((err) => {
            this.logger.warn("handleAdvert", err);
          });
        },
      );
    }

    if (this.cfg.advertiseOnNostr) {
      await this.publishLocalAdvert();
      const refreshMs = Math.max(
        1_000,
        Math.floor((this.cfg.advertTtlMs ?? DEFAULT_FIPS_ADVERT_TTL_MS) / 2),
      );
      this.advertRefreshTimer = setInterval(() => {
        if (this.stopping) return;
        void this.publishLocalAdvert().catch((err) => {
          this.logger.warn("advert refresh failed", err);
        });
      }, refreshMs);
    }
  }

  async stop(): Promise<void> {
    this.stopping = true;
    if (this.advertRefreshTimer) clearInterval(this.advertRefreshTimer);
    this.advertRefreshTimer = undefined;
    for (const timer of this.autoReconnectTimers.values()) clearTimeout(timer);
    this.autoReconnectTimers.clear();
    this.autoConnectPolicy.clearCooldowns();
    this.autoConnectAttempts.clear();
    this.autoConnectAttemptSequence = 0;
    if (this.autoConnectFillTimer) clearTimeout(this.autoConnectFillTimer);
    this.autoConnectFillTimer = undefined;
    this.advertCleanup?.();
    this.advertCleanup = undefined;
    this.peerDiscovery?.stop();
    for (const c of this.conns.values()) c.close();
    this.conns.clear();
    this.autoConnectPeers.clear();
    this.pendingAutoConnects.clear();
    if (this.ownsRelayClients) {
      for (const r of this.relayClients) r.close();
    }
    this.relayClients = [];
    this.ownsRelayClients = false;
    for (const dial of this.pendingDials.values()) {
      clearTimeout(dial.timer);
      cancelOfferRetry(dial);
      this.pendingDials.delete(dial.sessionId);
      dial.pc.close();
      dial.reject(new Error("transport stopped"));
    }
    for (const sessionId of this.pendingInbound.keys()) this.clearPendingInbound(sessionId, true);
    this.pendingConnects.clear();
    this.knownSessionIds.clear();
    this.seenSessionIds.clear();
    this.signalCache.clear();
    this.advertCache.clear();
    this.peersWithTraffic.clear();
    for (const [nodeAddrHex, waiters] of this.advertWaiters) {
      for (const waiter of [...waiters]) {
        this.settleAdvertWaiter(nodeAddrHex, waiter, undefined);
      }
    }
    this.advertWaiters.clear();
    this.discoveryStream?.close();
    this.discoveryStream = undefined;
    this.peerDiscovery = undefined;
    this.ctx = undefined;
  }

  private async handleAdvert(
    event: NostrEvent,
    advert: FipsAdvertContent,
    sourceRelayUrl: string,
  ): Promise<void> {
    const localPubkeyHex = this.ctx ? toHex(this.ctx.localIdentity.publicKey) : "";
    for (const endpoint of advert.endpoints) {
      if (endpoint.transport !== "webrtc" || !/^(02|03)[0-9a-fA-F]{64}$/.test(endpoint.addr)) {
        continue;
      }
      const remotePubkeyHex = endpoint.addr.toLowerCase();
      if (remotePubkeyHex.slice(2) !== event.pubkey.toLowerCase()) continue;
      if (remotePubkeyHex === localPubkeyHex) continue;
      if (!this.peerAllowed(remotePubkeyHex)) continue;
      const peer: DiscoveredPeer = {
        remoteAddr: { transport: this.type, addr: remotePubkeyHex },
        publicKey: fromHex(remotePubkeyHex),
        meta: { source: "nostr-advert", relayUrl: sourceRelayUrl },
      };
      const nodeAddrHex = nodeAddrToHex(deriveNodeAddr(peer.publicKey!));
      const previousCreatedAt = this.advertCache.createdAtSeconds(nodeAddrHex);
      const cached = this.advertCache.store(nodeAddrHex, peer, event);
      if (!cached) continue;
      if (previousCreatedAt !== undefined && event.created_at > previousCreatedAt) {
        this.handleAdvertRefresh(remotePubkeyHex);
      }
      const requested = this.resolveAdvertWaiters(nodeAddrHex, cached);
      if (this.cfg.autoConnect && !requested && !this.autoConnectFillTimer) {
        this.autoConnectFillTimer = setTimeout(() => {
          this.autoConnectFillTimer = undefined;
          this.fillAutoConnectSlots(localPubkeyHex);
        }, AUTO_CONNECT_SETTLE_MS);
      }
    }
  }

  /**
   * Replace the identities auto-connect dials first (for example the
   * application's own devices). Newly preferred peers are dialed at once.
   */
  setPreferredAutoConnectPeers(peers: readonly string[]): void {
    const added = new Set(this.autoConnectPolicy.setPreferredPeers(peers));
    if (added.size === 0) return;
    for (const [remote, timer] of this.autoReconnectTimers) {
      if (!added.has(remote.slice(2).toLowerCase())) continue;
      clearTimeout(timer);
      this.autoReconnectTimers.delete(remote);
    }
    this.fillAutoConnectSlots();
  }

  /** A live peer republished its advert: lift any failure backoff toward it. */
  private handleAdvertRefresh(remotePubkeyHex: string): void {
    if (!this.autoConnectPolicy.advertRefreshed(remotePubkeyHex)) return;
    clearTimeout(this.autoReconnectTimers.get(remotePubkeyHex));
    this.autoReconnectTimers.delete(remotePubkeyHex);
    this.logger.debug("webrtc auto-connect backoff cleared by newer advert", remotePubkeyHex);
  }

  private fillAutoConnectSlots(localPubkeyHex = this.ctx ? toHex(this.ctx.localIdentity.publicKey) : ""): void {
    if (!this.cfg.autoConnect || this.stopping || !this.ctx) return;
    const localXOnlyPubkey = localPubkeyHex.slice(2);
    const now = Date.now();
    this.advertCache.prune(now);
    this.autoConnectPolicy.pruneCooldowns(now);
    const partition = this.autoConnectPolicy.partitionByInitiator(
      [...this.advertCache.values()], localXOnlyPubkey, this.cfg.acceptConnections);
    const candidates = this.autoConnectPolicy.sort(
      partition.outbound,
      this.autoConnectAttempts,
      now,
    );
    const reservePreferredSlot = this.autoConnectPolicy.shouldReserveSlot(
      candidates.map((cached) => cached.peer.remoteAddr.addr),
      this.conns.keys(), this.pendingConnects.keys(), this.autoConnectPeers,
      partition.inbound.map((cached) => cached.peer.remoteAddr.addr),
    );
    for (const cached of candidates) {
      const remote = cached.peer.remoteAddr.addr;
      if (!this.peerAllowed(remote)) continue;
      const autoConnectLimit = this.autoConnectPolicy.connectionLimit(
        this.cfg.maxAutoConnections, reservePreferredSlot, remote);
      if (this.autoConnectCapacityUsed() >= autoConnectLimit) continue;
      // Preferred peers sort first and may exceed the speculative bound.
      if (!this.autoConnectPolicy.isPreferred(remote)
        && this.speculativeAutoConnects() >= this.maxSpeculativeAutoConnects()) return;
      const ownedRemote = this.ownedPeerAddress(remote);
      if (this.conns.has(ownedRemote) || this.pendingConnects.has(ownedRemote) || this.autoConnectPeers.has(remote)
        || hasPendingInboundForPeer(this.pendingInbound.values(), ownedRemote)) continue;
      if (this.autoConnectPolicy.cooldownUntil(remote) > now) continue;
      this.autoConnectAttempts.set(remote, ++this.autoConnectAttemptSequence);
      this.autoConnectPeers.add(remote);
      const push = () => {
        if (this.stopping || !this.ctx || this.conns.has(remote)) {
          this.autoConnectPeers.delete(remote);
          return;
        }
        this.logger.debug("webrtc auto-connect queued", remote);
        this.discoveryStream?.push(cloneDiscoveredPeer(cached.peer));
      };
      push();
    }
  }

  private async publishLocalAdvert(): Promise<void> {
    if (!this.ctx || !this.peerDiscovery) return;
    await this.peerDiscovery.publishAdvert({
      identifier: FIPS_ADVERT_D_TAG,
      version: 1,
      endpoints: [
        { transport: "webrtc", addr: toHex(this.ctx.localIdentity.publicKey) },
      ],
      stunServers: this.cfg.stunServers,
    });
  }

  async resolve(nodeAddr: NodeAddr, signal?: AbortSignal): Promise<DiscoveredPeer | undefined> {
    const nodeAddrHex = nodeAddrToHex(nodeAddr);
    const cached = this.advertCache.get(nodeAddrHex);
    // Resolution may race the discovery consumer. Keep any queued reservation
    // until connect() atomically transfers it to pendingAutoConnects.
    if (cached) return this.peerAllowed(cached.remoteAddr.addr) ? cached : undefined;
    if (!this.ctx || signal?.aborted) return undefined;

    return new Promise<DiscoveredPeer | undefined>((resolve) => {
      const waiter: AdvertWaiter = {
        resolve,
        timer: setTimeout(() => {
          this.settleAdvertWaiter(nodeAddrHex, waiter, undefined);
        }, ADVERT_RESOLUTION_TIMEOUT_MS),
        signal,
      };
      if (signal) {
        waiter.onAbort = () => this.settleAdvertWaiter(nodeAddrHex, waiter, undefined);
        signal.addEventListener("abort", waiter.onAbort, { once: true });
      }
      let waiters = this.advertWaiters.get(nodeAddrHex);
      if (!waiters) {
        waiters = new Set();
        this.advertWaiters.set(nodeAddrHex, waiters);
      }
      waiters.add(waiter);
    });
  }

  private resolveAdvertWaiters(nodeAddrHex: string, peer: DiscoveredPeer): boolean {
    const waiters = this.advertWaiters.get(nodeAddrHex);
    if (!waiters || waiters.size === 0) return false;
    for (const waiter of [...waiters]) {
      this.settleAdvertWaiter(nodeAddrHex, waiter, cloneDiscoveredPeer(peer));
    }
    return true;
  }

  private settleAdvertWaiter(
    nodeAddrHex: string,
    waiter: AdvertWaiter,
    peer: DiscoveredPeer | undefined,
  ): void {
    const waiters = this.advertWaiters.get(nodeAddrHex);
    if (!waiters?.delete(waiter)) return;
    if (waiters.size === 0) this.advertWaiters.delete(nodeAddrHex);
    clearTimeout(waiter.timer);
    if (waiter.signal && waiter.onAbort) {
      waiter.signal.removeEventListener("abort", waiter.onAbort);
    }
    waiter.resolve(peer);
  }

  discover(): AsyncIterable<DiscoveredPeer> {
    return this.discoveryStream ?? emptyAsyncIterable();
  }

  async connect(addr: TransportAddress): Promise<void> {
    if (addr.transport !== "webrtc") throw new Error("wrong transport");
    if (addr.addr.length !== 66) {
      throw new Error("WebRTC addr must be 33-byte compressed pubkey hex");
    }
    const remotePubkeyHex = this.ownedPeerAddress(addr.addr);
    if (!this.peerAllowed(remotePubkeyHex)) throw new Error("FIPS peer is blocked");
    // Discovery reservations only cover the queued handoff to FipsNode.
    // Once connect() starts, the concrete pending/connected maps own capacity.
    const isAutoConnect = this.autoConnectPeers.delete(addr.addr);
    if (this.conns.has(remotePubkeyHex)) return;
    const pendingConnect = this.pendingConnects.get(remotePubkeyHex);
    if (pendingConnect) {
      await pendingConnect;
      return;
    }
    if (isAutoConnect) this.pendingAutoConnects.add(remotePubkeyHex);
    if (!this.ctx?.sendLinkNegotiation) {
      throw new Error("WebRTC negotiation requires an authenticated FIPS route");
    }
    const sessionId = randomId();
    this.knownSessionIds.add(sessionId);
    this.logger.debug("webrtc connect start", remotePubkeyHex, sessionId);

    const pc = new this.RTCPC({
      iceServers: this.cfg.stunServers.map((u) => ({ urls: u })),
    });
    const dataChannelOptions: RTCDataChannelInit = {
      ordered: this.cfg.ordered,
    };
    if (this.cfg.maxRetransmits !== undefined && this.cfg.maxRetransmits !== null) {
      dataChannelOptions.maxRetransmits = this.cfg.maxRetransmits;
    }
    const dataChannel = pc.createDataChannel(this.cfg.dataChannelLabel, dataChannelOptions);

    let awaitingSessionRecovery = false;
    const connectPromise = new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => {
        cancelOfferRetry(dial);
        this.pendingDials.delete(sessionId);
        const detail = [
          `phase=${dial.phase}`,
          `connection=${pc.connectionState}`,
          `ice=${pc.iceConnectionState}`,
          `signaling=${pc.signalingState}`,
          `local=${pc.localDescription ? "set" : "missing"}`,
          `remote=${pc.remoteDescription ? "set" : "missing"}`,
        ].join(",");
        pc.close();
        reject(new Error(`WebRTC connect timeout (${detail})`));
      }, this.cfg.connectTimeoutMs);

      const dial: PendingDial = {
        sessionId,
        remotePubkeyHex,
        phase: "starting",
        pc,
        dataChannel,
        resolve,
        reject,
        timer,
      };
      this.pendingDials.set(sessionId, dial);

      this.startInitiatorHandshake(dial, addr).catch((err) => {
        awaitingSessionRecovery = dial.phase === "sending-offer";
        clearTimeout(timer);
        cancelOfferRetry(dial);
        this.pendingDials.delete(sessionId);
        pc.close();
        reject(err);
      });
    });
    this.pendingConnects.set(remotePubkeyHex, connectPromise);
    try {
      await connectPromise;
    } catch (error) {
      // A live inbound negotiation has taken ownership of this peer. It is
      // not a failed connection attempt and must not acquire a retry cooldown.
      if (!(error instanceof IncomingOfferHandoff)) {
        this.handleAutoConnectFailure(remotePubkeyHex, awaitingSessionRecovery);
      }
      throw error;
    } finally {
      if (this.pendingConnects.get(remotePubkeyHex) === connectPromise) {
        this.pendingConnects.delete(remotePubkeyHex);
      }
      if (!this.conns.has(remotePubkeyHex)) {
        this.autoConnectPeers.delete(remotePubkeyHex);
      }
      if (isAutoConnect) {
        this.pendingAutoConnects.delete(remotePubkeyHex);
        this.fillAutoConnectSlots();
      }
    }
  }

  async send(addr: TransportAddress, packet: Uint8Array): Promise<void> {
    if (!this.peerAllowed(addr.addr)) throw new Error("FIPS peer is blocked");
    const conn = this.conns.get(this.ownedPeerAddress(addr.addr));
    if (!conn) throw new Error(`no webrtc connection to ${addr.addr}`);
    if (packet.length > this.mtu) {
      throw new Error(`packet ${packet.length} exceeds MTU ${this.mtu}`);
    }
    conn.send(packet);
  }

  async close(addr: TransportAddress): Promise<void> {
    const remotePubkeyHex = this.ownedPeerAddress(addr.addr);
    for (const [sessionId, dial] of this.pendingDials) {
      if (dial.remotePubkeyHex !== remotePubkeyHex) continue;
      clearTimeout(dial.timer);
      cancelOfferRetry(dial);
      this.pendingDials.delete(sessionId);
      this.knownSessionIds.delete(sessionId);
      dial.pc.close();
      dial.reject(new Error("WebRTC path closed"));
    }
    for (const [sessionId, pending] of this.pendingInbound) {
      if (pending.remotePubkeyHex !== remotePubkeyHex) continue;
      this.clearPendingInbound(sessionId, true);
    }
    const provenPeer = this.peersWithTraffic.delete(remotePubkeyHex);
    this.retireExistingConnection(remotePubkeyHex);
    if (provenPeer || this.autoReconnectTimers.has(remotePubkeyHex)) {
      this.scheduleAutoReconnect(remotePubkeyHex);
      return;
    }
    this.handleAutoConnectFailure(remotePubkeyHex);
  }

  handlePeerRestart(remotePubkeyHex: string): Promise<void> {
    return this.close({ transport: this.type, addr: remotePubkeyHex });
  }

  handleSessionEstablished(remotePubkeyHex: string, restarted = false): void {
    if (!this.peerAllowed(remotePubkeyHex)) return;
    remotePubkeyHex = this.ownedPeerAddress(remotePubkeyHex);
    if (restarted) {
      retryOffersAfterRestart(remotePubkeyHex, this.pendingDials,
        (remote, signal) => this.sendWebRtcSignal(remote, signal), this.logger);
    }
    if (!this.autoConnectPolicy.recoverSession(remotePubkeyHex)) return;
    clearTimeout(this.autoReconnectTimers.get(remotePubkeyHex));
    this.autoReconnectTimers.delete(remotePubkeyHex);
    this.logger.debug("webrtc authenticated signaling recovered", remotePubkeyHex);
    this.scheduleAutoReconnect(remotePubkeyHex);
  }

  private async startInitiatorHandshake(dial: PendingDial, addr: TransportAddress): Promise<void> {
    const ownsDial = () => this.pendingDials.get(dial.sessionId) === dial;
    dial.phase = "creating-offer";
    const offer = await dial.pc.createOffer();
    if (!ownsDial()) return;
    dial.phase = "gathering-ice";
    await dial.pc.setLocalDescription(offer);
    if (!ownsDial()) return;
    await waitForIceGatheringComplete(dial.pc, this.cfg.iceGatherTimeoutMs);
    // An incoming offer can win while any of these operations is pending.
    // Never send the canceled offer or attach callbacks to its closed PC.
    if (!ownsDial()) return;
    await sendPendingOffer(dial, this.pendingDials,
      (remote, signal) => this.sendWebRtcSignal(remote, signal), this.logger);
    if (!ownsDial()) return;
    // Wire connection state to dialer promise once data channel opens.
    let conn: WebRtcConnection | null = null;
    const ownsConnection = () => ownsDial()
      || (conn !== null && this.conns.get(dial.remotePubkeyHex) === conn);
    conn = new WebRtcConnection({
      remotePubkeyHex: dial.remotePubkeyHex,
      remoteAddr: addr,
      pc: dial.pc,
      dataChannel: dial.dataChannel,
      onPacket: (data) => {
        if (!ownsConnection()) return;
        this.peersWithTraffic.add(dial.remotePubkeyHex);
        this.ctx?.onPacket({
          transportType: "webrtc",
          remoteAddr: addr,
          data,
          receivedAtMs: Date.now(),
        });
      },
      onState: (state) => {
        if (!ownsConnection()) return;
        if (conn && this.supersededConnections.has(conn)) return;
        this.ctx?.onConnectionState?.({ remoteAddr: addr, state });
        if (state === "connected") {
          if (conn) this.conns.set(dial.remotePubkeyHex, conn);
          this.autoConnectPolicy.recordSuccess(dial.remotePubkeyHex);
          if (this.pendingDials.delete(dial.sessionId)) {
            clearTimeout(dial.timer);
            cancelOfferRetry(dial);
            dial.resolve();
          }
        } else if (state === "failed" || state === "disconnected") {
          this.conns.delete(dial.remotePubkeyHex);
          this.scheduleAutoReconnect(dial.remotePubkeyHex);
          if (this.pendingDials.delete(dial.sessionId)) {
            clearTimeout(dial.timer);
            cancelOfferRetry(dial);
            dial.reject(new Error(`webrtc state ${state}`));
          }
          conn?.close();
        }
      },
      logger: this.logger,
    });
  }

  private async handleIncomingSignal(signal: WebRtcSignal, remotePubkeyHex: string): Promise<void> {
    if (!this.ctx) return;
    if (!this.peerAllowed(remotePubkeyHex)) return;
    remotePubkeyHex = this.ownedPeerAddress(remotePubkeyHex);
    this.logger.debug("webrtc signal received", signal.kind, signal.negotiationId, remotePubkeyHex);
    const localPubkeyHex = toHex(this.ctx.localIdentity.publicKey);
    const duplicate = this.signalCache.duplicate(signal, remotePubkeyHex);
    const valid = validateWebRtcSignal(signal, {
      knownNegotiationIds: this.knownSessionIds,
      seenNegotiationIds: duplicate ? new Set<string>() : this.seenSessionIds,
      nowMs: Date.now(),
    });
    if (duplicate) {
      if (valid.kind !== "offer" || duplicate.inFlight
        || Date.now() - duplicate.lastAttemptAtMs < 1_000) return;
      if (duplicate.response) {
        // Never replay an answer for a timed-out, replaced or closed PC.
        if (duplicate.responseIsLive && !duplicate.responseIsLive()) return;
        duplicate.inFlight = true;
        try {
          await this.sendWebRtcSignal(remotePubkeyHex, duplicate.response);
        } catch (error) {
          this.logger.debug("cached WebRTC response failed", error);
        } finally {
          duplicate.inFlight = false;
          duplicate.lastAttemptAtMs = Date.now();
        }
      } else if (duplicate.retryable) {
        // The previous handling failed, rather than merely still being in
        // flight. Only this authenticated peer and identical SDP may retry.
        duplicate.inFlight = true;
        await this.processIncomingOffer(valid, remotePubkeyHex, localPubkeyHex, duplicate);
      }
      return;
    }
    const answeringDial = valid.kind === "answer" ? this.pendingDials.get(valid.negotiationId) : undefined;
    if (answeringDial && answeringDial.remotePubkeyHex !== remotePubkeyHex) {
      throw new Error("WebRTC answer identity mismatch");
    }
    if (valid.kind === "offer") {
      const cached = this.signalCache.remember(valid, remotePubkeyHex);
      if (!cached) throw new Error("WebRTC negotiation replay cache full");
      this.seenSessionIds.add(`${valid.negotiationId}:${valid.kind}`);
      await this.processIncomingOffer(valid, remotePubkeyHex, localPubkeyHex, cached);
      return;
    }
    this.seenSessionIds.add(`${valid.negotiationId}:${valid.kind}`);
    if (valid.kind === "answer") {
      const dial = this.pendingDials.get(valid.negotiationId);
      if (!dial) return;
      cancelOfferRetry(dial);
      this.signalCache.remember(valid, remotePubkeyHex);
      dial.phase = "applying-answer";
      await dial.pc.setRemoteDescription({ type: "answer", sdp: valid.payload.sdp! });
      dial.phase = "opening-data-channel";
      this.logger.debug("webrtc answer applied", remotePubkeyHex, valid.negotiationId);
      return;
    }
    if (valid.kind === "reject") {
      const dial = this.pendingDials.get(valid.negotiationId);
      if (dial) {
        clearTimeout(dial.timer);
        cancelOfferRetry(dial);
        this.pendingDials.delete(valid.negotiationId);
        dial.pc.close();
        dial.reject(new Error("peer rejected"));
      }
      return;
    }
    // "candidate" not used in non-trickle v1.
  }

  private async processIncomingOffer(
    offer: WebRtcSignal, remote: string, local: string, cached: CachedSignal,
  ): Promise<void> {
    try {
      await this.handleIncomingOffer(offer, remote, local, cached);
    } catch (error) {
      cached.response = undefined;
      cached.responseIsLive = undefined;
      cached.retryable = true;
      throw error;
    } finally {
      cached.inFlight = false;
      cached.lastAttemptAtMs = Date.now();
    }
  }

  private async handleIncomingOffer(
    offer: WebRtcSignal,
    remotePubkeyHex: string,
    localPubkeyHex: string,
    cached: CachedSignal,
  ): Promise<void> {
    const context = this.ctx;
    if (this.pendingInbound.has(offer.negotiationId)) return;
    const competingDial = [...this.pendingDials.values()]
      .find((dial) => dial.remotePubkeyHex === remotePubkeyHex);
    if (!this.cfg.acceptConnections && !competingDial) {
      await this.rejectIncomingOffer(offer, remotePubkeyHex, cached);
      return;
    }
    const admitted = competingDial || !this.cfg.allowIncomingPeer
      || await this.cfg.allowIncomingPeer(remotePubkeyHex);
    if (this.ctx !== context || !this.peerAllowed(remotePubkeyHex)) return;
    if (!admitted) {
      await this.rejectIncomingOffer(offer, remotePubkeyHex, cached);
      return;
    }
    if (hasPendingInboundForPeer(this.pendingInbound.values(), remotePubkeyHex)) {
      await this.rejectIncomingOffer(offer, remotePubkeyHex, cached);
      return;
    }
    if (competingDial) {
      // Keep deterministic arbitration for the first crossed offer. A fresh
      // authenticated retry after rejection means the peer abandoned that
      // negotiation. Yield only while our winning offer is still unanswered,
      // so a lost offer cannot block recovery until the full dial deadline.
      const retryOfRejectedOffer = isRetryOfRejectedOffer(competingDial, offer.negotiationId);
      if (!incomingOfferReplacesPendingDial(localPubkeyHex, remotePubkeyHex)
        && !retryOfRejectedOffer) {
        competingDial.rejectedOfferId ??= offer.negotiationId;
        await this.rejectIncomingOffer(offer, remotePubkeyHex, cached);
        return;
      }
      clearTimeout(competingDial.timer);
      cancelOfferRetry(competingDial);
      this.pendingDials.delete(competingDial.sessionId);
      competingDial.pc.close();
      competingDial.reject(new IncomingOfferHandoff());
    }
    if (
      this.conns.size + this.pendingDials.size + this.pendingInbound.size
      - Number(this.conns.has(remotePubkeyHex))
      >= this.cfg.maxConnections
    ) {
      this.logger.warn("inbound WebRTC offer rejected at connection limit", remotePubkeyHex);
      await this.rejectIncomingOffer(offer, remotePubkeyHex, cached);
      return;
    }
    const remoteAddr: TransportAddress = { transport: "webrtc", addr: remotePubkeyHex };
    const pc = new this.RTCPC({
      iceServers: this.cfg.stunServers.map((u) => ({ urls: u })),
    });
    const timer = setTimeout(() => {
      this.pendingInbound.delete(offer.negotiationId);
      pc.close();
      if (competingDial) this.scheduleAutoReconnect(remotePubkeyHex);
    }, this.cfg.connectTimeoutMs);
    const pending = { timer, remotePubkeyHex, pc };
    this.pendingInbound.set(offer.negotiationId, pending);
    const ownsInbound = () => this.pendingInbound.get(offer.negotiationId) === pending;
    const dcPromise = new Promise<RTCDataChannel>((resolve) => {
      pc.ondatachannel = (evt) => resolve(evt.channel);
    });
    try {
      await pc.setRemoteDescription({ type: "offer", sdp: offer.payload.sdp! });
      if (!ownsInbound()) return;
      const answer = await pc.createAnswer();
      if (!ownsInbound()) return;
      await pc.setLocalDescription(answer);
      if (!ownsInbound()) return;
      await waitForIceGatheringComplete(pc, this.cfg.iceGatherTimeoutMs);
      if (!ownsInbound()) return;
      this.knownSessionIds.add(offer.negotiationId);
      const signal = createWebRtcSignal(offer.negotiationId, "answer", { sdp: pc.localDescription!.sdp });
      await sendAnswerWithRouteRetry(() => this.sendWebRtcSignal(remotePubkeyHex, signal), ownsInbound);
      if (!ownsInbound()) return;
      this.signalCache.rememberResponse(cached, signal, () => this.ctx === context
        && (ownsInbound() || this.conns.get(remotePubkeyHex)?.pc === pc)
        && pc.connectionState !== "closed" && pc.connectionState !== "failed");
      this.logger.debug("webrtc answer sent", remotePubkeyHex, offer.negotiationId);
    } catch (err) {
      this.clearPendingInbound(offer.negotiationId);
      pc.close();
      if (competingDial) this.scheduleAutoReconnect(remotePubkeyHex);
      throw err;
    }
    dcPromise.then((dataChannel) => {
      if (!ownsInbound()) { dataChannel.close(); return; }
      let conn: WebRtcConnection | null = null;
      const ownsConnection = () => ownsInbound()
        || (conn !== null && this.conns.get(remotePubkeyHex) === conn);
      conn = new WebRtcConnection({
        remotePubkeyHex,
        remoteAddr,
        pc,
        dataChannel,
        onPacket: (data) => {
          if (!ownsConnection()) return;
          this.peersWithTraffic.add(remotePubkeyHex);
          this.ctx?.onPacket({
            transportType: "webrtc",
            remoteAddr,
            data,
            receivedAtMs: Date.now(),
          });
        },
        onState: (state) => {
          if (!ownsConnection() || !conn || this.supersededConnections.has(conn)) return;
          this.handleInboundConnectionState(offer.negotiationId, conn, state);
        },
        logger: this.logger,
      });
    }).catch((err) => {
      this.clearPendingInbound(offer.negotiationId);
      this.logger.warn("dcPromise", err);
    });
  }

  private handleInboundConnectionState(
    negotiationId: string,
    conn: WebRtcConnection,
    state: "connecting" | "connected" | "disconnected" | "failed",
  ): void {
    const { remotePubkeyHex, remoteAddr } = conn;
    const existing = this.conns.get(remotePubkeyHex);
    if (state === "connected") {
      this.conns.set(remotePubkeyHex, conn);
      this.autoConnectPolicy.recordSuccess(remotePubkeyHex);
      this.clearPendingInbound(negotiationId);
      // Switch carriers only when ready. Retiring the old PC is not a
      // peer disconnect: its authenticated FMP/FSP state remains valid.
      if (existing && existing !== conn) {
        this.supersededConnections.add(existing);
        existing.close();
      }
      this.ctx?.onConnectionState?.({ remoteAddr, state });
      return;
    }
    if (existing && existing !== conn) {
      if (state === "failed" || state === "disconnected") {
        this.clearPendingInbound(negotiationId);
        conn.close();
      }
      return;
    }
    this.ctx?.onConnectionState?.({ remoteAddr, state });
    if (state === "failed" || state === "disconnected") {
      this.conns.delete(remotePubkeyHex);
      this.clearPendingInbound(negotiationId);
      conn.pc.close();
      this.scheduleAutoReconnect(remotePubkeyHex);
    }
  }

  private scheduleAutoReconnect(remotePubkeyHex: string): void {
    this.autoConnectPeers.delete(remotePubkeyHex);
    if (!this.cfg.autoConnect || this.stopping || !this.ctx) {
      this.logger.debug("webrtc auto-reconnect disabled", remotePubkeyHex);
      return;
    }
    if (this.autoReconnectTimers.has(remotePubkeyHex)) return;
    const delay = Math.max(
      AUTO_RECONNECT_DELAY_MS,
      this.autoConnectPolicy.cooldownUntil(remotePubkeyHex) - Date.now(),
    );
    this.logger.debug("webrtc auto-reconnect scheduled", remotePubkeyHex, delay);
    const timer = setTimeout(() => {
      this.autoReconnectTimers.delete(remotePubkeyHex);
      if (this.stopping || !this.ctx || this.conns.has(remotePubkeyHex)) {
        this.logger.debug("webrtc auto-reconnect no longer needed", remotePubkeyHex);
        return;
      }
      this.logger.debug("webrtc auto-reconnect retrying", remotePubkeyHex);
      this.fillAutoConnectSlots();
    }, delay);
    this.autoReconnectTimers.set(remotePubkeyHex, timer);
  }

  private ownedPeerAddress(remotePubkeyHex: string): string {
    const normalized = remotePubkeyHex.toLowerCase();
    if (!/^(02|03)[0-9a-f]{64}$/.test(normalized)) return normalized;
    const opposite = `${normalized.startsWith("02") ? "03" : "02"}${normalized.slice(2)}`;
    // Signaling authenticates an x-only identity, which can use the other
    // compressed parity from discovery. Keep the existing path's address.
    for (const candidate of [normalized, opposite]) {
      if (
        this.conns.has(candidate)
        || this.pendingConnects.has(candidate)
        || [...this.pendingDials.values()].some((dial) => dial.remotePubkeyHex === candidate)
        || hasPendingInboundForPeer(this.pendingInbound.values(), candidate)
      ) return candidate;
    }
    return normalized;
  }

  private retireExistingConnection(remotePubkeyHex: string): void {
    const existing = this.conns.get(remotePubkeyHex);
    if (!existing) return;
    this.conns.delete(remotePubkeyHex);
    this.peersWithTraffic.delete(remotePubkeyHex);
    this.supersededConnections.add(existing);
    this.ctx?.onConnectionState?.({
      remoteAddr: existing.remoteAddr,
      state: "disconnected",
    });
    existing.close();
    this.logger.debug("webrtc connection retired", remotePubkeyHex);
  }

  private handleAutoConnectFailure(remotePubkeyHex: string, awaitingSessionRecovery = false): void {
    if (!this.cfg.autoConnect || this.stopping) return;
    this.autoConnectPeers.delete(remotePubkeyHex);
    // While this node has no working link, failures say nothing about the peer.
    const attributable = this.ctx?.isLinked?.() ?? true;
    this.autoConnectPolicy.recordFailure(remotePubkeyHex, awaitingSessionRecovery, attributable);
    this.scheduleAutoReconnect(remotePubkeyHex);
    this.fillAutoConnectSlots();
  }

  private clearPendingInbound(sessionId: string, close = false): void {
    const pending = this.pendingInbound.get(sessionId);
    if (!pending) return;
    clearTimeout(pending.timer);
    this.pendingInbound.delete(sessionId);
    if (close) pending.pc.close();
  }

  private async rejectIncomingOffer(
    offer: WebRtcSignal, remotePubkeyHex: string, cached: CachedSignal,
  ): Promise<void> {
    const response = createWebRtcSignal(offer.negotiationId, "reject");
    await this.sendWebRtcSignal(remotePubkeyHex, response);
    this.signalCache.rememberResponse(cached, response);
  }

  async handleLinkNegotiation(remotePubkeyHex: string, message: LinkNegotiationMessage): Promise<void> {
    await this.handleIncomingSignal(message as WebRtcSignal, remotePubkeyHex);
  }

  private async sendWebRtcSignal(remotePubkeyHex: string, signal: WebRtcSignal): Promise<void> {
    if (!this.peerAllowed(remotePubkeyHex)) throw new Error("FIPS peer is blocked");
    if (!this.ctx?.sendLinkNegotiation) {
      throw new Error("WebRTC negotiation requires the FIPS link-negotiation service");
    }
    await this.ctx.sendLinkNegotiation(remotePubkeyHex, signal);
  }

  private peerAllowed(pubkeyHex: string): boolean {
    return this.ctx?.allowPeer?.(fromHex(pubkeyHex)) !== false;
  }

  private speculativeAutoConnects(): number {
    return this.autoConnectPeers.size + this.pendingAutoConnects.size;
  }

  private autoConnectCapacityUsed(): number {
    return this.conns.size
      + this.pendingDials.size
      + this.pendingInbound.size
      + this.autoConnectPeers.size;
  }

  private maxSpeculativeAutoConnects(): number { return Math.max(1, Math.floor(this.cfg.maxConnections / 2)); }
}
