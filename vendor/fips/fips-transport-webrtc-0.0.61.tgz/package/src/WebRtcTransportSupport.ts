import { toHex, type DiscoveredPeer } from "@fips/core";
import { randomBytes } from "@noble/hashes/utils";

import type { NostrEvent } from "./NostrRelayClient.js";
import {
  DEFAULT_STUN_SERVERS,
  DEFAULT_ICE_GATHER_TIMEOUT_MS,
  type WebRtcTransportConfig,
} from "./WebRtcTransportConfig.js";

export type ResolvedWebRtcTransportConfig = Required<
  Pick<
    WebRtcTransportConfig,
    | "relays"
    | "stunServers"
    | "advertiseOnNostr"
    | "acceptConnections"
    | "autoConnect"
    | "mtu"
    | "maxConnections"
    | "maxAutoConnections"
    | "connectTimeoutMs"
    | "relayConnectTimeoutMs"
    | "iceGatherTimeoutMs"
    | "dataChannelLabel"
    | "ordered"
  >
> & WebRtcTransportConfig;

export function resolveWebRtcTransportConfig(config: WebRtcTransportConfig): ResolvedWebRtcTransportConfig {
  const maxConnections = config.maxConnections ?? 32;
  return {
    relays: [],
    advertiseOnNostr: false,
    acceptConnections: config.acceptConnections ?? config.advertiseOnNostr ?? false,
    autoConnect: false,
    mtu: 1200,
    maxConnections,
    maxAutoConnections: Math.min(
      maxConnections,
      Math.max(0, config.maxAutoConnections ?? maxConnections),
    ),
    connectTimeoutMs: 30_000,
    relayConnectTimeoutMs: 5_000,
    dataChannelLabel: "fips",
    ordered: true,
    ...config,
    stunServers: [...(config.stunServers ?? DEFAULT_STUN_SERVERS)],
    iceGatherTimeoutMs: config.iceGatherTimeoutMs ?? DEFAULT_ICE_GATHER_TIMEOUT_MS,
  };
}

export interface PendingInboundConnection {
  timer: ReturnType<typeof setTimeout>;
  remotePubkeyHex: string;
  pc: RTCPeerConnection;
}

export function randomId(): string {
  return toHex(randomBytes(16));
}

export function incomingOfferReplacesPendingDial(
  localPubkeyHex: string,
  remotePubkeyHex: string,
): boolean {
  // Rust FIPS orders the complete x-only identity, independent of the
  // compressed key's parity. Discovery advertises the even encoding.
  return localPubkeyHex.slice(2).toLowerCase() > remotePubkeyHex.slice(2).toLowerCase();
}

export function hasPendingInboundForPeer(
  pending: Iterable<{ remotePubkeyHex: string }>,
  remotePubkeyHex: string,
): boolean {
  return [...pending].some((item) => item.remotePubkeyHex === remotePubkeyHex);
}

export function waitForIceGatheringComplete(
  pc: RTCPeerConnection,
  timeoutMs: number,
): Promise<void> {
  if (pc.iceGatheringState === "complete") return Promise.resolve();
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      pc.removeEventListener("icegatheringstatechange", onChange);
      resolve();
    }, timeoutMs);
    function onChange() {
      if (pc.iceGatheringState === "complete") {
        clearTimeout(timer);
        pc.removeEventListener("icegatheringstatechange", onChange);
        resolve();
      }
    }
    pc.addEventListener("icegatheringstatechange", onChange);
  });
}

export class AsyncEventStream<T> implements AsyncIterable<T> {
  private readonly values: T[] = [];
  private readonly waiters: Array<(result: IteratorResult<T>) => void> = [];
  private closed = false;

  push(value: T): void {
    if (this.closed) return;
    const waiter = this.waiters.shift();
    if (waiter) waiter({ done: false, value });
    else this.values.push(value);
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    this.values.length = 0;
    for (const waiter of this.waiters.splice(0)) {
      waiter({ done: true, value: undefined });
    }
  }

  [Symbol.asyncIterator](): AsyncIterator<T> {
    return {
      next: () => {
        const value = this.values.shift();
        if (value !== undefined) return Promise.resolve({ done: false, value });
        if (this.closed) return Promise.resolve({ done: true, value: undefined });
        return new Promise<IteratorResult<T>>((resolve) => {
          this.waiters.push(resolve);
        });
      },
    };
  }
}

export async function* emptyAsyncIterable<T>(): AsyncIterable<T> {
  return;
}

export function cloneDiscoveredPeer(peer: DiscoveredPeer): DiscoveredPeer {
  return {
    remoteAddr: { ...peer.remoteAddr },
    publicKey: peer.publicKey ? new Uint8Array(peer.publicKey) : undefined,
    meta: peer.meta
      ? Object.fromEntries(Object.entries(peer.meta).map(([key, value]) => [
        key,
        Array.isArray(value) ? [...value] : value,
      ]))
      : undefined,
  };
}

export function advertExpiryMs(
  event: NostrEvent,
  ttlMs: number,
  nowMs: number,
): number | undefined {
  if (!Number.isFinite(ttlMs) || ttlMs <= 0) return undefined;
  const createdAtMs = event.created_at * 1_000;
  if (!Number.isSafeInteger(createdAtMs) || createdAtMs < 0) return undefined;
  const localExpiryMs = Math.min(createdAtMs + ttlMs, nowMs + ttlMs);
  const expiration = event.tags.find((tag) => tag[0] === "expiration")?.[1];
  if (expiration === undefined) return localExpiryMs;
  if (!/^\d+$/.test(expiration)) return undefined;
  const advertisedExpiryMs = Number(expiration) * 1_000;
  if (!Number.isSafeInteger(advertisedExpiryMs)) return undefined;
  return Math.min(localExpiryMs, advertisedExpiryMs);
}

export interface AdvertWaiter {
  resolve: (peer: DiscoveredPeer | undefined) => void;
  timer: ReturnType<typeof setTimeout>;
  signal?: AbortSignal;
  onAbort?: () => void;
}
