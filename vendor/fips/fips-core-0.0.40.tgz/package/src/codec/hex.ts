export { bytesToHex as toHex, hexToBytes as fromHex, concatBytes } from "@noble/hashes/utils";

export function bytesEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}
