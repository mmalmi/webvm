import { bytesEqual, toHex } from "../codec/hex.js";
import { FmpLink, type FmpHandshakeResult } from "../fmp/link.js";
import { DirectFspTransportReassembler, isDirectFspTransportFragment } from "../fsp/directTransport.js";
import { isDirectFspEstablished } from "../fsp/wire.js";
import type { FipsIdentity } from "../identity/index.js";
import { compareNodeAddr, deriveNodeAddr, nodeAddrToHex } from "../nodeaddr/index.js";
import {
  decodeFmpEstablished,
  decodeFmpMsg2,
  FMP_INNER_KEEPALIVE,
  FMP_PHASE_ESTABLISHED,
  FMP_PHASE_MSG1,
  FMP_PHASE_MSG2,
  peekFmpPhase,
} from "../fmp/wire.js";
import {
  transportAddressKey,
  type Logger,
  type ReceivedTransportPacket,
  type Transport,
  type TransportAddress,
} from "../transport/types.js";

import type { FipsRouting } from "./FipsRouting.js";
import type { FspSessionManager } from "./FspSessionManager.js";
import { pruneDrainingResponderLinks, sameCompressedIdentity, type AdjacentPeer } from "./PeerState.js";
import { PendingFmpResponders } from "./PendingFmpResponders.js";
import { receiveFmpLinkPacket } from "./FmpLinkReports.js";
import type { PeerEvent } from "./types.js";

const FMP_REPLACED_LINK_DRAIN_MS = 10_000;
const FMP_REMOTE_EPOCH_HISTORY_LIMIT = 8;

interface FmpTransportPacketProcessorConfig {
  identity: FipsIdentity;
  startupEpoch: Uint8Array;
  nextSessionIdx: () => number;
  randomBytes: (length: number) => Uint8Array;
  logger: Logger;
  peers: Map<string, AdjacentPeer>;
  peersByPubkey: Map<string, AdjacentPeer>;
  peersByNodeAddr: Map<string, AdjacentPeer>;
  routing: FipsRouting;
  sessionManager: FspSessionManager;
  emitError: (error: Error, where: string) => void;
  emitPeer: (event: PeerEvent) => void;
  removePeerPath: (peer: AdjacentPeer) => void;
  handlePeerRestart: (remotePubkeyHex: string, preserveTransport: Transport) => void;
}

interface AuthenticatedMsg1Context {
  peer: AdjacentPeer;
  result: FmpHandshakeResult;
  handshakeLink: FmpLink;
  peerEpochBeforeMsg1?: Uint8Array;
  transport: Transport;
  remoteAddr: TransportAddress;
  key: string;
  replacedHandshake?: AdjacentPeer["outgoingHandshake"];
  wasEstablished: boolean;
}

export class FmpTransportPacketProcessor {
  private readonly reassembler = new DirectFspTransportReassembler();
  private readonly remoteEpochHistory = new Map<string, string[]>();
  private readonly pendingResponders: PendingFmpResponders;

  constructor(private readonly cfg: FmpTransportPacketProcessorConfig) {
    this.pendingResponders = new PendingFmpResponders(cfg.removePeerPath);
  }

  clear(): void {
    this.pendingResponders.clear();
    this.reassembler.clear();
    this.remoteEpochHistory.clear();
  }

  discardPendingResponder(peer: AdjacentPeer): void {
    this.pendingResponders.discard(peer);
  }

  process(transport: Transport, received: ReceivedTransportPacket): void {
    try {
      const key = transportAddressKey(received.remoteAddr);
      const peer = this.cfg.peers.get(key)
        ?? this.findXOnlyTransportPeer(transport, received.remoteAddr);
      let packet = received.data;
      if (isDirectFspTransportFragment(packet)) {
        if (!peer || peer.link.state !== "established" || peer.pubkey.length === 0) {
          throw new Error("direct FSP fragment before adjacent link handshake complete");
        }
        const reassembled = this.reassembler.ingest(key, packet, received.receivedAtMs);
        if (!reassembled) return;
        packet = reassembled;
      }
      if (isDirectFspEstablished(packet)) {
        if (!peer || peer.link.state !== "established" || peer.pubkey.length === 0) {
          throw new Error("direct FSP before adjacent link handshake complete");
        }
        void this.cfg.sessionManager
          .handleFromPeer(peer, deriveNodeAddr(peer.pubkey), packet)
          .catch((error) => this.cfg.emitError(error as Error, "direct-fsp"));
        return;
      }
      const phase = peekFmpPhase(packet);
      this.cfg.logger.debug(
        "fips packet received",
        received.remoteAddr.transport,
        received.remoteAddr.addr,
        packet.length,
        phase,
      );
      if (phase === FMP_PHASE_MSG1) {
        this.handleMsg1(transport, received.remoteAddr, key, peer, packet);
        return;
      }
      if (phase === FMP_PHASE_MSG2) {
        this.handleMsg2(transport, received.remoteAddr, peer, packet);
        return;
      }
      if (phase === FMP_PHASE_ESTABLISHED) {
        this.handleEstablished(received.remoteAddr, peer, packet);
        return;
      }
      throw new Error(`unknown FMP phase ${phase}`);
    } catch (error) {
      this.cfg.emitError(error as Error, "onTransportPacket");
      this.cfg.logger.warn("transport packet error", error);
    }
  }

  private handleMsg1(
    transport: Transport,
    remoteAddr: TransportAddress,
    key: string,
    initialPeer: AdjacentPeer | undefined,
    packet: Uint8Array,
  ): void {
    const prepared = this.prepareMsg1Peer(transport, remoteAddr, key, initialPeer);
    if (!prepared) return;
    let { peer } = prepared;
    const {
      peerEpochBeforeMsg1,
      replacedEstablishedInitiator,
      replacedHandshake,
      stageEstablishedInitiator,
    } = prepared;
    let wasEstablished = replacedEstablishedInitiator || peer.link.state === "established";
    let result: FmpHandshakeResult;
    let handshakeLink: FmpLink;
    if (stageEstablishedInitiator
      || (peer.pendingResponderLink && peer.link.state !== "established")) {
      result = this.stageResponderReplacement(peer, packet);
      handshakeLink = peer.pendingResponderLink!;
      this.cfg.logger.debug(
        "staged responder link for established initiator",
        remoteAddr.transport,
        remoteAddr.addr,
      );
    } else if (peer.link.state === "established") {
      try {
        result = peer.link.handleMsg1(packet, this.cfg.randomBytes);
        handshakeLink = peer.link;
      } catch (error) {
        if (!(error instanceof Error)
          || error.message !== "unexpected FMP Msg1 after establishment") {
          throw error;
        }
        result = this.stageResponderReplacement(peer, packet);
        handshakeLink = peer.pendingResponderLink!;
        this.cfg.logger.debug(
          "staged responder link after fresh authenticated Msg1",
          remoteAddr.transport,
          remoteAddr.addr,
        );
      }
    } else {
      result = peer.link.handleMsg1(packet, this.cfg.randomBytes);
      handshakeLink = peer.link;
    }
    const reconciled = this.reconcileAuthenticatedMsg1({
      peer,
      result,
      handshakeLink,
      peerEpochBeforeMsg1,
      transport,
      remoteAddr,
      key,
      replacedHandshake,
      wasEstablished,
    });
    if (!reconciled) return;
    peer = reconciled.peer;
    wasEstablished = reconciled.wasEstablished;
    const reply = result.reply;
    let replySent: Promise<void> | undefined;
    if (reply) {
      replySent = transport.send(remoteAddr, reply);
      void replySent.catch((error) => {
        this.cfg.emitError(error as Error, "send Msg2");
      });
      this.cfg.logger.debug(
        "fips msg2 sent",
        remoteAddr.transport,
        remoteAddr.addr,
        reply.length,
      );
    }
    if (replacedHandshake && !reconciled.identityRebound) {
      peer.outgoingHandshake = undefined;
      replacedHandshake.resolve();
    }
    if (!wasEstablished) {
      this.cfg.emitPeer({
        remotePubkey: peer.pubkeyHex,
        remoteAddr: peer.remoteAddr,
        state: "connected",
      });
      this.replayPendingLookupsAfterEstablishment(peer, replySent);
    }
  }

  private reconcileAuthenticatedMsg1(
    context: AuthenticatedMsg1Context,
  ): { peer: AdjacentPeer; wasEstablished: boolean; identityRebound: boolean } | undefined {
    let { peer, wasEstablished } = context;
    const {
      result,
      handshakeLink,
      peerEpochBeforeMsg1,
      transport,
      remoteAddr,
      key,
      replacedHandshake,
    } = context;
    const remotePubkeyHex = toHex(result.remotePubkey);
    const identityChanged = peer.pubkey.length > 0
      && !sameCompressedIdentity(peer.pubkey, result.remotePubkey);
    let identityRebound = false;
    if (identityChanged) {
      if (!transport.identityMayChangeAtAddress) {
        handshakeLink.close();
        if (peer.pendingResponderLink === handshakeLink) this.pendingResponders.take(peer);
        throw new Error("fresh FMP Msg1 changed the authenticated peer identity");
      }
      if (peer.link.state === "established") {
        this.removeRestartedPeerPaths(peer.pubkeyHex, handshakeLink, transport);
      } else {
        peer.link.close();
        this.pendingResponders.take(peer);
      }
      peer = {
        pubkey: result.remotePubkey,
        pubkeyHex: remotePubkeyHex,
        remoteAddr,
        transport,
        link: handshakeLink,
      };
      this.cfg.peers.set(key, peer);
      wasEstablished = false;
      identityRebound = true;
      this.cfg.logger.info(
        "FMP transport address authenticated a replacement identity",
        remoteAddr.transport,
        remoteAddr.addr,
      );
    } else {
      const previousRemoteEpoch = peerEpochBeforeMsg1
        ?? this.establishedRemoteEpoch(remotePubkeyHex, handshakeLink);
      const candidateEpoch = handshakeLink.remoteEpoch;
      const changedEpoch = previousRemoteEpoch !== undefined
        && candidateEpoch !== undefined
        && !bytesEqual(previousRemoteEpoch, candidateEpoch);
      if (this.rejectRetiredEpoch(
        peer,
        handshakeLink,
        remotePubkeyHex,
        candidateEpoch,
        changedEpoch,
        remoteAddr,
      )) return undefined;
      if (changedEpoch) {
        this.removeRestartedPeerPaths(
          remotePubkeyHex,
          handshakeLink,
          transport,
          replacedHandshake,
        );
        peer = {
          pubkey: result.remotePubkey,
          pubkeyHex: remotePubkeyHex,
          remoteAddr,
          transport,
          link: handshakeLink,
        };
        this.cfg.peers.set(key, peer);
        wasEstablished = false;
        this.cfg.logger.info("FMP peer restart detected", remotePubkeyHex);
      } else if (replacedHandshake && peer.link !== handshakeLink) {
        peer.abandonedInitiatorSessionIdx = peer.link.localSessionIdx;
        peer.link.close();
        peer.link = handshakeLink;
        this.pendingResponders.take(peer);
      }
    }
    peer.pubkey = result.remotePubkey;
    peer.pubkeyHex = remotePubkeyHex;
    if (!identityRebound && !replacedHandshake
      && this.stageUnconfirmedCarrier(peer, handshakeLink)) {
      wasEstablished = true;
    } else {
      this.rememberPeer(peer);
    }
    return { peer, wasEstablished, identityRebound };
  }

  private stageUnconfirmedCarrier(peer: AdjacentPeer, handshakeLink: FmpLink): boolean {
    if (peer.link !== handshakeLink) {
      return peer.link.state !== "established" && peer.pendingResponderLink === handshakeLink;
    }
    if (!this.establishedRemoteEpoch(peer.pubkeyHex, handshakeLink)) return false;
    // Msg1 authenticates an identity, but a captured Msg1 can be replayed on
    // another carrier. Keep that carrier inactive until it decrypts a frame.
    this.pendingResponders.set(peer, handshakeLink);
    peer.link = this.newResponderLink();
    return true;
  }

  private prepareMsg1Peer(
    transport: Transport,
    remoteAddr: TransportAddress,
    key: string,
    initialPeer: AdjacentPeer | undefined,
  ): {
    peer: AdjacentPeer;
    peerEpochBeforeMsg1?: Uint8Array;
    replacedEstablishedInitiator: boolean;
    replacedHandshake?: AdjacentPeer["outgoingHandshake"];
    stageEstablishedInitiator: boolean;
  } | undefined {
    let peer = initialPeer;
    const peerEpochBeforeMsg1 = peer?.link.remoteEpoch?.slice();
    let replacedEstablishedInitiator = false;
    let replacedHandshake: AdjacentPeer["outgoingHandshake"];
    let stageEstablishedInitiator = false;
    if (peer?.link.role === "initiator" && peer.outgoingHandshake) {
      if (peer.pubkey.length === 0) {
        throw new Error("outbound FMP peer is missing its expected identity");
      }
      const order = compareNodeAddr(this.cfg.identity.nodeAddr, deriveNodeAddr(peer.pubkey));
      if (order < 0) {
        this.cfg.logger.debug(
          "simultaneous FMP handshake: local initiator wins",
          remoteAddr.transport,
          remoteAddr.addr,
        );
        return undefined;
      }
      if (order === 0) throw new Error("simultaneous FMP handshake with local identity");
      replacedEstablishedInitiator = peer.link.state === "established";
      replacedHandshake = peer.outgoingHandshake;
      stageEstablishedInitiator = true;
      this.cfg.logger.debug(
        "simultaneous FMP handshake: staging remote initiator winner",
        remoteAddr.transport,
        remoteAddr.addr,
      );
    } else if (peer?.link.role === "initiator") {
      stageEstablishedInitiator = true;
    }
    if (!peer) {
      peer = {
        pubkey: new Uint8Array(0),
        pubkeyHex: "",
        remoteAddr,
        transport,
        link: this.newResponderLink(),
      };
      this.cfg.peers.set(key, peer);
    }
    return {
      peer,
      peerEpochBeforeMsg1,
      replacedEstablishedInitiator,
      replacedHandshake,
      stageEstablishedInitiator,
    };
  }

  private rejectRetiredEpoch(
    peer: AdjacentPeer,
    handshakeLink: FmpLink,
    remotePubkeyHex: string,
    candidateEpoch: Uint8Array | undefined,
    changedEpoch: boolean,
    remoteAddr: TransportAddress,
  ): boolean {
    if (!changedEpoch || !candidateEpoch) return false;
    if (!this.isRetiredRemoteEpoch(remotePubkeyHex, candidateEpoch)) return false;
    handshakeLink.close();
    if (peer.pendingResponderLink === handshakeLink) this.pendingResponders.take(peer);
    this.cfg.logger.debug(
      "ignored FMP Msg1 from a retired startup epoch",
      remoteAddr.transport,
      remoteAddr.addr,
    );
    return true;
  }

  private handleMsg2(
    transport: Transport,
    remoteAddr: TransportAddress,
    addressedPeer: AdjacentPeer | undefined,
    packet: Uint8Array,
  ): void {
    const msg2 = decodeFmpMsg2(packet);
    const peer = this.matchMsg2Peer(msg2.receiverIdx);
    if (!peer) {
      if (addressedPeer?.abandonedInitiatorSessionIdx === msg2.receiverIdx) {
        addressedPeer.abandonedInitiatorSessionIdx = undefined;
        this.cfg.logger.debug(
          "ignored Msg2 for abandoned simultaneous FMP initiator",
          remoteAddr.transport,
          remoteAddr.addr,
        );
        return;
      }
      this.cfg.logger.debug(
        "ignored Msg2 with no pending FMP initiator",
        remoteAddr.transport,
        remoteAddr.addr,
        msg2.receiverIdx,
      );
      return;
    }
    const wasEstablished = peer.link.state === "established";
    const previousRemoteEpoch = this.establishedRemoteEpoch(peer.pubkeyHex, peer.link);
    const restartedHandshake = peer.outgoingHandshake;
    peer.link.handleMsg2(packet);
    peer.pubkey = peer.link.remotePubkey!;
    peer.pubkeyHex = toHex(peer.link.remotePubkey!);
    const candidateEpoch = peer.link.remoteEpoch;
    const changedEpoch = previousRemoteEpoch !== undefined
      && candidateEpoch !== undefined
      && !bytesEqual(previousRemoteEpoch, candidateEpoch);
    if (changedEpoch && candidateEpoch) {
      if (this.isRetiredRemoteEpoch(peer.pubkeyHex, candidateEpoch)) {
        this.rejectRetiredMsg2Peer(peer, remoteAddr);
        return;
      }
      this.removeRestartedPeerPaths(
        peer.pubkeyHex,
        peer.link,
        transport,
        restartedHandshake,
      );
      this.cfg.peers.set(transportAddressKey(peer.remoteAddr), peer);
      this.cfg.logger.info("FMP peer restart detected", peer.pubkeyHex);
    }
    if (!wasEstablished) {
      void this.confirmOutgoingHandshake(peer, remoteAddr);
    }
    this.cfg.logger.debug("fips msg2 handled", remoteAddr.transport, remoteAddr.addr);
  }

  private async confirmOutgoingHandshake(peer: AdjacentPeer, remoteAddr: TransportAddress): Promise<void> {
    const handshake = peer.outgoingHandshake;
    const link = peer.link;
    if (!handshake) return;
    let confirmationSent = false;
    let confirmationReceived = false;
    const complete = () => {
      if (!confirmationSent || peer.outgoingHandshake !== handshake || peer.link !== link
        || link.state !== "established") return;
      const current = this.cfg.peersByPubkey.get(peer.pubkeyHex);
      if (current !== peer && current?.link.state === "established"
        && !confirmationReceived) return;
      this.retireDisplacedMsg2Peer(remoteAddr, peer);
      this.rememberPeer(peer);
      this.cfg.emitPeer({
        remotePubkey: peer.pubkeyHex,
        remoteAddr: peer.remoteAddr,
        state: "connected",
      });
      handshake.resolve();
      peer.outgoingHandshake = undefined;
      this.cfg.routing.scheduleTreeAnnounce(peer);
      this.replayPendingLookupsAfterEstablishment(peer);
    };
    handshake.confirmCarrier = () => {
      confirmationReceived = true;
      complete();
    };
    try {
      // Sending confirms our side; an alternate must also receive confirmation
      // before it can replace the healthy path used by direct FSP data.
      await peer.transport.send(
        peer.remoteAddr, link.encryptOutgoing(new Uint8Array(0), FMP_INNER_KEEPALIVE),
      );
      confirmationSent = true;
      complete();
    } catch (error) {
      if (peer.outgoingHandshake === handshake && peer.link === link) {
        handshake.reject(error as Error);
      }
    }
  }

  private replayPendingLookupsAfterEstablishment(
    peer: AdjacentPeer,
    establishmentReply?: Promise<void>,
  ): void {
    const replay = () => {
      void this.cfg.routing.replayPendingLookupsFor(peer).catch((error) => {
        this.cfg.emitError(error as Error, "replay pending lookups");
      });
    };
    if (establishmentReply) void establishmentReply.then(replay, () => undefined);
    else replay();
  }

  private matchMsg2Peer(receiverIdx: number): AdjacentPeer | undefined {
    const matches = new Set<AdjacentPeer>();
    for (const candidate of this.cfg.peers.values()) {
      if (
        candidate.outgoingHandshake
        && candidate.link.role === "initiator"
        && candidate.link.localSessionIdx === receiverIdx
      ) {
        matches.add(candidate);
      }
    }
    return matches.size === 1 ? matches.values().next().value : undefined;
  }

  private retireDisplacedMsg2Peer(
    remoteAddr: TransportAddress,
    peer: AdjacentPeer,
  ): void {
    const key = transportAddressKey(remoteAddr);
    const displaced = this.cfg.peers.get(key);
    if (!displaced || displaced === peer) return;
    for (const [candidateKey, candidate] of this.cfg.peers) {
      if (candidate === displaced) this.cfg.peers.delete(candidateKey);
    }
    this.drainAuthenticatedLink(peer, displaced.link);
    const pending = this.pendingResponders.take(displaced);
    if (pending) this.drainAuthenticatedLink(peer, pending);
    for (const draining of displaced.drainingResponderLinks?.values() ?? []) {
      this.drainAuthenticatedLink(peer, draining.link, draining.expiresAtMs);
    }
    displaced.outgoingHandshake?.reject(new Error("authenticated FMP path replaced address alias"));
    if (this.cfg.peersByPubkey.get(displaced.pubkeyHex) === displaced) {
      this.cfg.peersByPubkey.delete(displaced.pubkeyHex);
    }
    if (displaced.pubkey.length > 0) {
      const nodeAddrHex = nodeAddrToHex(deriveNodeAddr(displaced.pubkey));
      if (this.cfg.peersByNodeAddr.get(nodeAddrHex) === displaced) {
        this.cfg.peersByNodeAddr.delete(nodeAddrHex);
      }
    }
  }

  private drainAuthenticatedLink(
    peer: AdjacentPeer,
    link: FmpLink,
    expiresAtMs = Date.now() + FMP_REPLACED_LINK_DRAIN_MS,
  ): void {
    if (link === peer.link || link === peer.pendingResponderLink) return;
    if (link.state !== "established") {
      link.close();
      return;
    }
    const draining = peer.drainingResponderLinks ?? new Map();
    const existing = draining.get(link.localSessionIdx);
    if (existing && existing.link !== link) {
      link.close();
      return;
    }
    draining.set(link.localSessionIdx, { link, expiresAtMs });
    peer.drainingResponderLinks = draining;
  }

  private handleEstablished(
    remoteAddr: TransportAddress,
    _addressedPeer: AdjacentPeer | undefined,
    packet: Uint8Array,
  ): void {
    const receiverIdx = decodeFmpEstablished(packet).receiverIdx;
    const match = this.matchEstablishedLink(receiverIdx);
    if (!match) {
      this.cfg.logger.debug(
        "ignored FMP Established with no matching receiver index",
        remoteAddr.transport,
        remoteAddr.addr,
        receiverIdx,
      );
      return;
    }
    const { peer, link, promotePending } = match;
    const { msgType, payload } = receiveFmpLinkPacket(peer, link, packet, this.cfg.emitError);
    if (peer.link === link) peer.outgoingHandshake?.confirmCarrier?.();
    if (promotePending) {
      const previous = peer.link;
      peer.link = link;
      this.pendingResponders.take(peer);
      if (previous.state === "established") {
        this.drainAuthenticatedLink(peer, previous);
      } else {
        previous.close();
        this.rememberPeer(peer);
        this.cfg.emitPeer({
          remotePubkey: peer.pubkeyHex,
          remoteAddr: peer.remoteAddr,
          state: "connected",
        });
        this.replayPendingLookupsAfterEstablishment(peer);
      }
      this.cfg.logger.debug(
        "promoted authenticated responder link",
        remoteAddr.transport,
        remoteAddr.addr,
        receiverIdx,
      );
    }
    this.cfg.routing.scheduleTreeAnnounce(peer);
    this.cfg.routing.handleLinkMessage(peer, msgType, payload).catch((error) => {
      this.cfg.emitError(error as Error, "link-message");
    });
  }

  private matchEstablishedLink(receiverIdx: number): {
    peer: AdjacentPeer;
    link: FmpLink;
    promotePending: boolean;
  } | undefined {
    const matches = new Map<FmpLink, {
      peer: AdjacentPeer;
      link: FmpLink;
      promotePending: boolean;
    }>();
    const nowMs = Date.now();
    for (const peer of new Set(this.cfg.peers.values())) {
      pruneDrainingResponderLinks(peer, nowMs);
      if (
        peer.link.state === "established"
        && peer.link.localSessionIdx === receiverIdx
      ) {
        matches.set(peer.link, { peer, link: peer.link, promotePending: false });
      }
      if (
        peer.pendingResponderLink?.state === "established"
        && peer.pendingResponderLink.localSessionIdx === receiverIdx
      ) {
        matches.set(peer.pendingResponderLink, {
          peer,
          link: peer.pendingResponderLink,
          promotePending: true,
        });
      }
      const draining = peer.drainingResponderLinks?.get(receiverIdx);
      if (draining) {
        matches.set(draining.link, { peer, link: draining.link, promotePending: false });
      }
    }
    if (matches.size > 1) {
      throw new Error(`ambiguous FMP Established receiver_idx ${receiverIdx}`);
    }
    return matches.values().next().value;
  }

  private newResponderLink(): FmpLink {
    return new FmpLink({
      identity: this.cfg.identity,
      role: "responder",
      sessionIdx: this.cfg.nextSessionIdx(),
      localEpoch: this.cfg.startupEpoch,
    });
  }

  private rememberPeer(peer: AdjacentPeer): void {
    if (peer.pubkey.length === 0 || !peer.pubkeyHex) return;
    this.cfg.peersByPubkey.set(peer.pubkeyHex, peer);
    this.cfg.peersByNodeAddr.set(nodeAddrToHex(deriveNodeAddr(peer.pubkey)), peer);
    if (peer.link.remoteEpoch) this.rememberRemoteEpoch(peer.pubkeyHex, peer.link.remoteEpoch);
  }

  private rememberRemoteEpoch(remotePubkeyHex: string, epoch: Uint8Array): void {
    const encoded = toHex(epoch);
    const history = this.remoteEpochHistory.get(remotePubkeyHex) ?? [];
    if (history.includes(encoded)) return;
    history.push(encoded);
    if (history.length > FMP_REMOTE_EPOCH_HISTORY_LIMIT) history.shift();
    this.remoteEpochHistory.set(remotePubkeyHex, history);
  }

  private isRetiredRemoteEpoch(remotePubkeyHex: string, epoch: Uint8Array): boolean {
    return this.remoteEpochHistory.get(remotePubkeyHex)?.includes(toHex(epoch)) ?? false;
  }

  private rejectRetiredMsg2Peer(peer: AdjacentPeer, remoteAddr: TransportAddress): void {
    peer.link.close();
    for (const [key, candidate] of this.cfg.peers) {
      if (candidate === peer) this.cfg.peers.delete(key);
    }
    const alternate = [...this.cfg.peers.values()].find((candidate) =>
      candidate !== peer
      && candidate.pubkeyHex === peer.pubkeyHex
      && candidate.link.state === "established"
    );
    if (alternate) {
      this.rememberPeer(alternate);
      this.cfg.routing.scheduleTreeAnnounce(alternate);
    } else {
      if (this.cfg.peersByPubkey.get(peer.pubkeyHex) === peer) {
        this.cfg.peersByPubkey.delete(peer.pubkeyHex);
      }
      if (peer.pubkey.length > 0) {
        const nodeAddrHex = nodeAddrToHex(deriveNodeAddr(peer.pubkey));
        if (this.cfg.peersByNodeAddr.get(nodeAddrHex) === peer) {
          this.cfg.peersByNodeAddr.delete(nodeAddrHex);
        }
      }
    }
    peer.outgoingHandshake?.reject(new Error("remote FIPS peer replied from a retired startup epoch"));
    peer.outgoingHandshake = undefined;
    this.cfg.logger.debug(
      "ignored FMP Msg2 from a retired startup epoch",
      remoteAddr.transport,
      remoteAddr.addr,
    );
  }

  private findXOnlyTransportPeer(
    transport: Transport,
    remoteAddr: TransportAddress,
  ): AdjacentPeer | undefined {
    if (!/^[0-9a-fA-F]{64}$/.test(remoteAddr.addr)) return undefined;
    const xOnly = remoteAddr.addr.toLowerCase();
    for (const peer of this.cfg.peers.values()) {
      if (peer.transport !== transport || peer.pubkey.length !== 33) continue;
      if (peer.pubkeyHex.slice(2).toLowerCase() === xOnly) return peer;
    }
    return undefined;
  }

  private establishedRemoteEpoch(
    remotePubkeyHex: string,
    excludingLink: FmpLink,
  ): Uint8Array | undefined {
    if (!remotePubkeyHex) return undefined;
    for (const candidate of this.cfg.peers.values()) {
      if (
        candidate.pubkeyHex !== remotePubkeyHex
        || candidate.link === excludingLink
        || candidate.link.state !== "established"
        || !candidate.link.remoteEpoch
      ) {
        continue;
      }
      return candidate.link.remoteEpoch.slice();
    }
    return undefined;
  }

  private removeRestartedPeerPaths(
    remotePubkeyHex: string,
    preserveLink: FmpLink,
    preserveTransport: Transport,
    preserveHandshake?: AdjacentPeer["outgoingHandshake"],
  ): void {
    let remotePubkey: Uint8Array | undefined;
    const removedPeers = new Set<AdjacentPeer>();
    for (const [pathKey, candidate] of [...this.cfg.peers]) {
      if (candidate.pubkeyHex !== remotePubkeyHex) continue;
      remotePubkey = candidate.pubkey;
      this.cfg.peers.delete(pathKey);
      removedPeers.add(candidate);
    }
    for (const candidate of removedPeers) {
      const wasConnected = candidate.link !== preserveLink
        && candidate.link.state === "established"
        && !candidate.outgoingHandshake;
      if (candidate.link !== preserveLink) candidate.link.close();
      const pending = this.pendingResponders.take(candidate);
      if (pending !== preserveLink) pending?.close();
      for (const draining of candidate.drainingResponderLinks?.values() ?? []) {
        if (draining.link !== preserveLink) draining.link.close();
      }
      if (candidate.outgoingHandshake && candidate.outgoingHandshake !== preserveHandshake) {
        candidate.outgoingHandshake.reject(new Error("remote FIPS peer restarted"));
        candidate.outgoingHandshake = undefined;
      }
      if (wasConnected) {
        this.cfg.emitPeer({
          remotePubkey: candidate.pubkeyHex,
          remoteAddr: candidate.remoteAddr,
          state: "disconnected",
        });
      }
    }
    this.cfg.peersByPubkey.delete(remotePubkeyHex);
    if (remotePubkey) {
      const remoteNodeAddr = deriveNodeAddr(remotePubkey);
      this.cfg.peersByNodeAddr.delete(nodeAddrToHex(remoteNodeAddr));
      this.cfg.routing.removePeer(remoteNodeAddr);
    }
    this.cfg.sessionManager.closePeerSessions(remotePubkeyHex);
    this.cfg.handlePeerRestart(remotePubkeyHex, preserveTransport);
  }

  private stageResponderReplacement(
    peer: AdjacentPeer,
    packet: Uint8Array,
  ): FmpHandshakeResult {
    let replacement = peer.pendingResponderLink;
    if (replacement) {
      try {
        return replacement.handleMsg1(packet, this.cfg.randomBytes);
      } catch (error) {
        if (!(error instanceof Error)
          || error.message !== "unexpected FMP Msg1 after establishment") {
          throw error;
        }
        this.discardPendingResponder(peer);
      }
    }
    replacement = this.newResponderLink();
    const result = replacement.handleMsg1(packet, this.cfg.randomBytes);
    this.pendingResponders.set(peer, replacement);
    return result;
  }
}
