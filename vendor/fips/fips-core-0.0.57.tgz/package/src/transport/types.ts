import type { FipsIdentity } from "../identity/index.js";
import type { LinkNegotiationMessage } from "../linkNegotiation.js";
import type { NodeAddr } from "../nodeaddr/index.js";

/**
 * Transport address — identifies an adjacent peer at the transport layer.
 *
 * For WebRTC, `addr` is the remote pubkey hex (NOT a session id or relay
 * URL). For memory transport it's also a pubkey hex.
 */
export interface TransportAddress {
  transport: string;
  addr: string;
}

export function transportAddressKey(a: TransportAddress): string {
  return `${a.transport}:${a.addr}`;
}

export interface ReceivedTransportPacket {
  transportType: string;
  remoteAddr: TransportAddress;
  data: Uint8Array;
  receivedAtMs: number;
}

export interface TransportConnectionStateEvent {
  remoteAddr: TransportAddress;
  state: "connecting" | "connected" | "disconnected" | "failed";
  reason?: string;
}

export interface DiscoveredPeer {
  remoteAddr: TransportAddress;
  /** Remote FIPS identity hint. Ethernet beacons may provide the 32-byte x-only form. */
  publicKey?: Uint8Array;
  meta?: Record<string, unknown>;
}

export interface TransportContext {
  localIdentity: FipsIdentity;
  onPacket(packet: ReceivedTransportPacket): void;
  onConnectionState?: (event: TransportConnectionStateEvent) => void;
  /** Establish another configured transport path to the same identity. */
  connectTransport?: (addr: TransportAddress) => Promise<void>;
  /** Carry link negotiation through the existing FSP DataPacket service. */
  sendLinkNegotiation?: (
    remotePubkeyHex: string,
    message: LinkNegotiationMessage,
  ) => Promise<void>;
  logger?: Logger;
  /** Current node admission policy; adapters must recheck after asynchronous preparation. */
  allowPeer?: (publicKey: Uint8Array) => boolean;
  /** Whether any authenticated adjacent link is up; tells local isolation from a dead remote. */
  isLinked?: () => boolean;
}

export interface Transport {
  readonly type: string;
  readonly mtu: number;
  /** Hard record limit for framed carriers that already accept more than their preferred MTU. */
  readonly maxFrameBytes?: number;
  /** A physical address such as a VM MAC may later authenticate a replacement identity. */
  readonly identityMayChangeAtAddress?: boolean;

  start(ctx: TransportContext): Promise<void>;
  stop(): Promise<void>;

  connect(addr: TransportAddress): Promise<void>;
  send(addr: TransportAddress, packet: Uint8Array): Promise<void>;
  close?(addr: TransportAddress): Promise<void>;
  discover?(): AsyncIterable<DiscoveredPeer>;
  /** Resolve a FIPS NodeAddr to an authenticated transport identity hint. */
  resolve?(nodeAddr: NodeAddr, signal?: AbortSignal): Promise<DiscoveredPeer | undefined>;
  /** Application-owned fallback transports enabled with this transport. */
  companionTransports?(): Transport[];
  /** Retire state keyed by an authenticated FIPS identity after its process restarts. */
  handlePeerRestart?(remotePubkeyHex: string): Promise<void>;
  /** A fresh authenticated FSP session can carry link negotiation to this identity. */
  handleSessionEstablished?(remotePubkeyHex: string, restarted?: boolean): void;
  /** Receive authenticated link negotiation addressed to this adapter type. */
  handleLinkNegotiation?(
    remotePubkeyHex: string,
    message: LinkNegotiationMessage,
  ): Promise<void> | void;
}

export interface Logger {
  debug(...args: unknown[]): void;
  info(...args: unknown[]): void;
  warn(...args: unknown[]): void;
  error(...args: unknown[]): void;
}

export const noopLogger: Logger = {
  debug: () => {},
  info: () => {},
  warn: () => {},
  error: () => {},
};
